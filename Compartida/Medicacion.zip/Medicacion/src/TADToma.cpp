//============================================================================
// Name        : TADToma.cpp
// Author      : Profesores de la asignatura IP/FP
// Version     : curso 20/21
// Copyright   : Your copyright notice
// Description : Implementación del TAD Toma
//============================================================================

#include "TADToma.h"

void nuevo(Toma &t, int id, string medicamento, int momento) {
	t.idPersona   = id;
	t.medicamento = medicamento;
	t.momento     = momento;
	t.veces       = 0;
}

void incrementarVeces(Toma &t) {
	t.veces++;
}

int obtenerIdentificador(Toma t) {
	return t.idPersona;
}

string obtenerMedicamento(Toma t) {
	return t.medicamento;
}

int obtenerMomento(Toma t) {
	return t.momento;
}

int obtenerVeces(Toma t) {
	return t.veces;
}

void mostrar (Toma t){
	cout <<"Id: "<< t.idPersona << "\t medicamento: "<< t.medicamento<< "\t momento: "<< t.momento << "\t veces: "<< t.veces<<endl;
}
