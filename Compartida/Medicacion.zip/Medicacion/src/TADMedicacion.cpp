//============================================================================
// Name        : TADMedicacion.cpp
// Author      : Profesores de la asignatura IP/FP
// Version     : curso 20/21
// Copyright   : Your copyright notice
// Description : Implementación del TAD Medicación
//============================================================================
#include "TADMedicacion.h"

void iniciar(Medicacion &m) {
	// TODO
}

void insertar(Medicacion &m, int id, string medicamento, int momento) {
	// TODO
}

int darTurno(Medicacion &m, int momento) {
	// TODO
	return -1;

}

int masVeces(Medicacion m, string &medicamento) {
	// TODO
	return -1;

}

void eliminar(Medicacion &m, int id) {
	// TODO
}

void mostrar(Medicacion m) {
	// TODO
}

int cuantos(Medicacion m) {
	// TODO implementar
	return -1;
}
