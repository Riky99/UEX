//============================================================================
// Name        : TADToma.h
// Author      : Profesores de la asignatura IP/FP
// Version     : curso 20/21
// Copyright   : Your copyright notice
// Description : Diseño y especificación del TAD Toma
//============================================================================

#ifndef TADTOMA_H_
#define TADTOMA_H_

#include <string>
#include <iostream>
using namespace std;

struct Toma {
	int    idPersona;
	string medicamento;
	int    momento;
	int    veces;
};
/*
 * PRE:  { }
 * POST: { devuelve t inicializada con los valores pasados como parámetros}
 * COMPLEJIDAD: O(1)
 */
void   nuevo                (Toma &t, int id, string medicamento, int momento);
/*
 * PRE:  { t inicializada }
 * POST: { Incrementa el número de veces de la toma t en 1}
 * COMPLEJIDAD: O(1)
 */
void   incrementarVeces     (Toma &t);
/*
 * PRE:  { t inicializada }
 * POST: { devuelve el id de la toma t}
 * COMPLEJIDAD: O(1)
 */
int    obtenerIdentificador (Toma t);
/*
 * PRE:  { t inicializada }
 * POST: { devuelve el nombre del medicamento de la toma t}
 * COMPLEJIDAD: O(1)
 */
string obtenerMedicamento   (Toma t);
/*
 * PRE:  { t inicializada }
 * POST: { devuelve el momento de la toma t}
 * COMPLEJIDAD: O(1)
 */
int    obtenerMomento       (Toma t);
/*
 * PRE:  { t inicializada }
 * POST: { devuelve las veces que se ha hecho la toma t}
 * COMPLEJIDAD: O(1)
 */
int    obtenerVeces         (Toma t);
/*
 * PRE:  { t inicializada }
 * POST: { muestra por pantalla los valores de la toma t}
 * COMPLEJIDAD: O(1)
 */
void   mostrar              (Toma t);
#endif /* TADTOMA_H_ */
