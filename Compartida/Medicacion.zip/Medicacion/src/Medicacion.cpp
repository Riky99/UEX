//============================================================================
// Name        : Act7_Medicacion.cpp
// Author      : Profesores de la asignatura IP/FP
// Version     : curso 20/21
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "pruebasToma.h"
#include "pruebasMedicacion.h"
#include "TADMedicacion.h"
#include "TADToma.h"
using namespace std;

int menu (){
	int opcion;
	cout <<endl<<endl;
	cout << "1.- Insertar     "<< endl;
	cout << "2.- Dar turno  "<< endl;
	cout << "3.- Más veces  "<< endl;
	cout << "4.- Eliminar     "<< endl;
	cout << "5.- Mostrar      "<< endl;
	cout <<endl;
	cout << "6.- Terminar           "<< endl;
	cin>> opcion;
	return opcion;
}
void ejecutar() {


	bool terminar = false;
	int opcion = 0;

	// TODO declara e inicializar la variable del tipo Medicamento

	while (!terminar) {
		opcion = menu();
		cin.ignore();
		switch (opcion) {
		case 1:
			// TODO insertar
			break;
		case 2:
			// TODO dar turno
			break;
		case 3:
			// TODO más veces
			break;
		case 4:
			// TODO eliminar
			break;
		case 5:
			// TODO mostrar
			break;
		case 6:
			terminar = true;
			break;
		}
	}
}


int main() {
	pruebaToma();
	pruebasMedicacion();
	ejecutar();

	return 0;
}
