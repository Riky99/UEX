//============================================================================
// Name        : pruebasToma.h
// Author      : Profesores de la asignatura IP/FP
// Version     : curso 20/21
// Copyright   : Your copyright notice
// Description : Diseño de las pruebas del TADToma
//============================================================================

#ifndef PRUEBASTOMA_H_
#define PRUEBASTOMA_H_
#include "TADToma.h"

/*
 * Diseño de las pruebas
 *
 * caso 1: Creamos la Toma t1 = { id = 1    medicamento = Sintróm   momento =  2}
 *         Obtenemos sus datos, comprobar que coinciden con los usados al crear t
 *
 *         Incrementar el número de veces tomada
 * 		   Comprobar obteniendo el valor modificado, la salida esperada debe ser 1
 *
 * caso 2: Creamos la Toma t2 = { id = 2    medicamento = Heparina sódica   momento =  1}
 *         Prueba supervisada
 *         		Mostramos los datos de t2, veces == 0
 *
 *  	        Incrementar el número de veces tomada
 *	     	    Mostramos los datos de t2 , veces == 1
 *
 *         		Incrementar el número de veces tomada
 *	       		Mostramos los datos de t2 , veces == 2
 */


void pruebaToma();

#endif /* PRUEBASTOMA_H_ */
