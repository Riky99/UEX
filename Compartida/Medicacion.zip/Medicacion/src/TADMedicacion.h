//============================================================================
// Name        : TADMedicacion.h
// Author      : Profesores de la asignatura IP/FP
// Version     : curso 20/21
// Copyright   : Your copyright notice
// Description : Diseño y especificación del TAD Medicación
//============================================================================

#ifndef TADMEDICACION_H_
#define TADMEDICACION_H_
#include <string>
#include <iostream>
#include "TADToma.h"
using namespace std;

// Declaración  tipo de dato

const int MAX = 300;

typedef Toma TVectorMedicacion[MAX];

struct Medicacion {
	TVectorMedicacion v;
	int ocupadas;
};
/*
 * PRE:  { }
 * POST: { }
 * COMPLEJIDAD: O()
 */
void iniciar  (Medicacion &m);
/*
 * PRE:  { }
 * POST: { }
 * COMPLEJIDAD: O()
 */
void insertar (Medicacion &m, int id, string medicamento, int momento);
/*
 * PRE:  { }
 * POST: { }
 * COMPLEJIDAD: O()
 */
int  darTurno (Medicacion &m, int momento);
/*
 * PRE:  { }
 * POST: { }
 * COMPLEJIDAD: O()
 */
int  masVeces (Medicacion m, string &medicamento);
/*
 * PRE:  { }
 * POST: { }
 * COMPLEJIDAD: O()
 */
void eliminar (Medicacion &m, int id);
/*
 * PRE:  { }
 * POST: { }
 * COMPLEJIDAD: O()
 */
void mostrar  (Medicacion m);
/*
 * PRE:  { }
 * POST: { }
 * COMPLEJIDAD: O()
 */
int  cuantos  (Medicacion m);


#endif /* TADMEDICACION_H_ */
