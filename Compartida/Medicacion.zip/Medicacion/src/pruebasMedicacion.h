//============================================================================
// Name        : pruebasMedicación.h
// Author      : Profesores de la asignatura IP/FP
// Version     : curso 20/21
// Copyright   : Your copyright notice
// Description : Diseño de las pruebas del tad Medicación
//============================================================================

#ifndef PRUEBASMEDICACION_H_
#define PRUEBASMEDICACION_H_
#include "TADMedicacion.h"


/*
 * Al iniciar la función cuantos debe devolver 0, vov vacio
 */
void pruebaIniciar    ();


/*
 --------------------------------------------------------------
 Diseño de los casos de prueba
 --------------------------------------------------------------
  Casos de prueba sobre un vov inicializado "m". Ocupación = 0

  Datos de entrada a insertar:

         Id      medicamento     momento	cuantos (nº elementos después de insertar)
       ______________________________________________________
 Toma 1:   1 	 Sintróm 		      2	 	   1
 Toma 2:   8 	 Heparina		      1        2
 Toma 3:   3 	 Insulina 			  4        3
 Toma 4:   5 	 Salbutamol  	      1        4
 Toma 5:   2 	 Tramadol             3        5
 Toma 6:   6 	 Remdesivir	          1        6
 Toma 7:   1     Sintróm              2 existe 6
 Toma 8:   1     Pacetamol            4        7
 Toma 9:   7 	 Sintróm 		      2        8
 Toma 10:  1 	 Omeprazol		      2        9



Al mostrar el contenido comprobamos las tomas insertadas deben ser 9


Salida esperada:

Id: 1 	medicamento: Sintróm	momento: 2	veces: 0
Id: 1 	medicamento: Pacetamol	momento: 4	veces: 0
Id: 1 	medicamento: Omeprazol	momento: 2	veces: 0
Id: 2 	medicamento: Tramadol	momento: 3	veces: 0
Id: 3 	medicamento: Insulina 	momento: 4	veces: 0
Id: 5 	medicamento: Salbutamol	momento: 1	veces: 0
Id: 6 	medicamento: Remdesivir	momento: 1	veces: 0
Id: 7 	medicamento: Sintróm	momento: 2	veces: 0
Id: 8 	medicamento: Heparina 	momento: 1	veces: 0
 */
void pruebasInsertar();

/*
--------------------------------------------------------------
Diseño de los casos de prueba
--------------------------------------------------------------
 Casos de prueba sobre un vov inicializado "m". Ocupación = 0

 Datos de entrada a insertar:

        Id      medicamento     momento	cuantos (nº elementos después de insertar)
      ______________________________________________________
 Toma 1:   1 	 Sintróm 		    2	 	 1
 Toma 2:   8 	 Heparina			1        2
 Toma 3:   3 	 Insulina 			4        3
 Toma 4:   5 	 Salbutamol  	    1        4
 Toma 5:   2 	 Tramadol           3        5
 Toma 6:   6 	 Remdesivir	        1        6
 Toma 7:   1     Sintróm            2 existe 6
 Toma 8:   1     Pacetamol          4        7
 Toma 9:   7 	 Sintróm 		    2        8
 Toma 10:  1 	 Omeprazol		    2        9



 Caso 1:  damos turnos al momento = 1
 ----- valor de veces después de dar turno momento 1, veces = 1 ------
	Id: 1 	medicamento: Sintróm	momento: 2	veces: 0
	Id: 1 	medicamento: Pacetamol	momento: 4	veces: 0
	Id: 1 	medicamento: Omeprazol	momento: 2	veces: 0
	Id: 2 	medicamento: Tramadol	momento: 3	veces: 0
	Id: 3 	medicamento: Insulina 	momento: 4	veces: 0
	Id: 5 	medicamento: Salbutamol	momento: 1	veces: 1
	Id: 6 	medicamento: Remdesivir	momento: 1	veces: 1
	Id: 7 	medicamento: Sintróm	momento: 2	veces: 0
	Id: 8 	medicamento: Heparina 	momento: 1	veces: 1

 Caso 2:  damos turnos al momento = 1
 ----- valor de veces después de dar turno momento 1, veces = 2------
	Id: 1 	medicamento: Sintróm	momento: 2	veces: 0
	Id: 1 	medicamento: Pacetamol	momento: 4	veces: 0
	Id: 1 	medicamento: Omeprazol	momento: 2	veces: 0
	Id: 2 	medicamento: Tramadol	momento: 3	veces: 0
	Id: 3 	medicamento: Insulina 	momento: 4	veces: 0
	Id: 5 	medicamento: Salbutamol	momento: 1	veces: 2
	Id: 6 	medicamento: Remdesivir	momento: 1	veces: 2
	Id: 7 	medicamento: Sintróm	momento: 2	veces: 0
	Id: 8 	medicamento: Heparina 	momento: 1	veces: 2

 Caso 3:  damos turnos al momento = 2
----- valor de veces después de dar turno momento 2, veces = 1------
	Id: 1 	medicamento: Sintróm	momento: 2	veces: 1
	Id: 1 	medicamento: Pacetamol	momento: 4	veces: 0
	Id: 1 	medicamento: Omeprazol	momento: 2	veces: 1
	Id: 2 	medicamento: Tramadol	momento: 3	veces: 0
	Id: 3 	medicamento: Insulina 	momento: 4	veces: 0
	Id: 5 	medicamento: Salbutamol	momento: 1	veces: 2
	Id: 6 	medicamento: Remdesivir	momento: 1	veces: 2
	Id: 7 	medicamento: Sintróm	momento: 2	veces: 1
	Id: 8 	medicamento: Heparina 	momento: 1	veces: 2
*/

void pruebasDarTurno();
/*
--------------------------------------------------------------
Diseño de los casos de prueba
--------------------------------------------------------------
 Casos de prueba sobre un vov inicializado "m". Ocupación = 0

 Datos de entrada a insertar:

        Id      medicamento     momento	cuantos (nº elementos después de insertar)
      ______________________________________________________
 Toma 1:   1 	 Sintróm 		    2	 	 1
 Toma 2:   8 	 Heparina			1        2
 Toma 3:   3 	 Insulina 			4        3
 Toma 4:   5 	 Salbutamol  	    1        4
 Toma 5:   2 	 Tramadol           3        5
 Toma 6:   6 	 Remdesivir	        1        6
 Toma 7:   1     Sintróm            2 existe 6
 Toma 8:   1     Pacetamol          4        7
 Toma 9:   7 	 Sintróm 		    2        8
 Toma 10:  1 	 Omeprazol		    2        9

 Caso 1:  damos turnos 3 veces al momento = 3
          salida espera para más veces: id = 2 y  medicamento= "Tramadol"
 Caso 2:  damos turnos 4 veces al momento = 4
          salida espera para más veces: id = 1 y  medicamento= "Paracetamol"
 Caso 3:  damos turnos 5 veces al momento = 1
          salida espera para más veces: id = 5 y  medicamento= "Salbutamol"
*/
void pruebasMasVeces();

/*
 --------------------------------------------------------------
 Diseño de los casos de prueba
 --------------------------------------------------------------
  Casos de prueba sobre un vov inicializado "m". Ocupación = 0

  Datos de entrada a insertar:

         Id      medicamento     momento	cuantos (nº elementos después de insertar)
       ______________________________________________________
 Toma 1:   1 	 Sintróm 		        2	 	 1
 Toma 2:   8 	 Heparina				1        2
 Toma 3:   3 	 Insulina 			    4        3
 Toma 4:   5 	 Salbutamol  	        1        4
 Toma 5:   2 	 Tramadol               3        5
 Toma 6:   6 	 Remdesivir	            1        6
 Toma 7:   1     Sintróm            	2 existe 6
 Toma 8:   1     Pacetamol              4        7
 Toma 9:   7 	 Sintróm 		        2        8
 Toma 10:  1 	 Omeprazol		        2        9

 Antes de eliminar cuantos = 9
 Caso 1: Eliminar tomas paciente id = 3 (posición intermedia)
 	 	 Después de eliminar cuantos = 8
 Caso 2: Eliminar tomas paciente id = 1 (posición inicial)
 	 	 Después de eliminar cuantos = 5
 Caso 3: Eliminar tomas paciente id = 8 (posición final )
 	 	 Después de eliminar cuantos = 4
*/

void pruebasEliminar();

// todas las pruebas
void pruebasMedicacion();

#endif /* PRUEBASMEDICACION_H_ */
