
//============================================================================
// Name        : pruebasToma.cpp
// Author      : Profesores de la asignatura IP/FP
// Version     : curso 20/21
// Copyright   : Your copyright notice
// Description : Implementación de las pruebas del TADToma
//============================================================================

#include "pruebasToma.h"
#include <iostream>
using namespace std;

void pruebaToma(){
	Toma t1, t2;
	cout << "Inicio prueba Toma"<<endl;
	nuevo(t1, 1, "Sintróm", 2);
	if (obtenerIdentificador(t1) != 1){
		cout << "Error en el identificador de la toma t1"<<endl;
	}

	if (obtenerMedicamento(t1) != "Sintróm"){
		cout << "Error en el nombre del medicamento de la toma t1"<<endl;
	}

	if (obtenerMomento(t1) != 2){
		cout << "Error en el momento de la toma t1"<<endl;
	}
	if (obtenerVeces(t1) != 0){
		cout << "Error en el nº de veces de la toma t1"<<endl;
	}

	incrementarVeces(t1);
	if (obtenerVeces(t1) != 1){
			cout << "Error en incrementar  veces de la toma t1"<<endl;
	}

	// prueba supervisada, usuamos el módulo mostrar para comprobar que la toma se ha creado correctamente
	nuevo(t2, 2, "Heparina sódica", 1);
	cout << "Mostrando t2 ..."<<endl;
	mostrar(t2);
	incrementarVeces(t2);
	cout << "Mostrando t2 después de incrementar veces, \"veces == 1\""<<endl;
	mostrar(t2);
	incrementarVeces(t2);
	cout << "Mostrando t2 después de incrementar veces, \"veces == 2\"..."<<endl;
	mostrar(t2);
	cout << "Fin prueba Toma"<<endl;
}
