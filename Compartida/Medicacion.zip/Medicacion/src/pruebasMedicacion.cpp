//============================================================================
// Name        : pruebasMedicación.h
// Author      : Profesores de la asignatura IP/FP
// Version     : curso 20/21
// Copyright   : Your copyright notice
// Description : Implementación de las pruebas del tad Medicación
//============================================================================

#include "pruebasMedicacion.h"

void pruebaIniciar() {
	cout << "INICIO pruebas iniciar"<<endl;
	Medicacion m;
	iniciar(m);
	if (cuantos(m) != 0){
		cout << "Error al iniciar el vov"<<endl;
	}

	cout << "FIN pruebas iniciar"<<endl;

}


void pruebasInsertar() {
	Medicacion m;
	cout << "INICIO pruebas insertar"<<endl;
	iniciar(m);

	insertar (m, 1, "Sintróm",    2);
	if (cuantos(m)!= 1)
			cout << "Error al insertar toma 1 "<<endl;

	insertar (m, 8, "Heparina ",  1);
	if (cuantos(m)!= 2)
			cout << "Error al insertar toma 2 "<<endl;

	insertar (m, 3,	"Insulina ",  4);
	if (cuantos(m)!= 3)
				cout << "Error al insertar toma 3 "<<endl;

	insertar (m, 5,	"Salbutamol", 1);
	if (cuantos(m)!= 4)
				cout << "Error al insertar toma 4 "<<endl;

	insertar (m, 2,	"Tramadol",   3);
	if (cuantos(m)!= 5)
				cout << "Error al insertar toma 5 "<<endl;

	insertar (m, 6,	"Remdesivir", 1);
	if (cuantos(m)!= 6)
			cout << "Error al insertar toma 6 "<<endl;

	insertar (m, 1, "Sintróm",    2); // el dato existe , no se inserta
	if (cuantos(m)!= 6)
			cout << "Error al insertar toma 6 "<<endl;

	insertar (m, 1, "Pacetamol",  4);
	if (cuantos(m)!= 7)
			cout << "Error al insertar toma 7 "<<endl;

	insertar (m, 7, "Sintróm",    2);
	if (cuantos(m)!= 8)
			cout << "Error al insertar toma 8 "<<endl;

	insertar (m, 1, "Omeprazol",  2);
	if (cuantos(m)!= 9)
			cout << "Error al insertar toma 9 "<<endl;


   // Prueba Supervisada: mostramos los datos del vov, ocupadas == 9
	cout << "Prueba supervisada: tras insertar "<< cuantos(m) << "tomas la lista de tomas debería ser:" << endl << endl;
	cout << "\t Id: 1 	medicamento: Sintróm	momento: 2	veces: 0" << endl;
	cout << "\t Id: 1 	medicamento: Pacetamol	momento: 4	veces: 0" << endl;
	cout << "\t Id: 1 	medicamento: Omeprazol	momento: 2	veces: 0" << endl;
	cout << "\t Id: 2 	medicamento: Tramadol	momento: 3	veces: 0" << endl;
	cout << "\t Id: 3 	medicamento: Insulina 	momento: 4	veces: 0" << endl;
	cout << "\t Id: 5 	medicamento: Salbutamol	momento: 1	veces: 0" << endl;
	cout << "\t Id: 6 	medicamento: Remdesivir	momento: 1	veces: 0" << endl;
	cout << "\t Id: 7 	medicamento: Sintróm	momento: 2	veces: 0" << endl;
	cout << "\t Id: 8 	medicamento: Heparina 	momento: 1	veces: 0" << endl << endl;
	cout << "Y es: " << endl << endl;
	mostrar(m);
	cout << "FIN pruebas insertar"<<endl;
}


void pruebasDarTurno() {
	Medicacion m;
	cout << "INICIO pruebas dar Turno - supervisada"<<endl;
	int momento;
	iniciar(m);
	// insertamos el conjunto de datos con el que trabajar
	insertar (m, 1, "Sintróm",    2);
	insertar (m, 8, "Heparina ",  1);
	insertar (m, 3,	"Insulina ",  4);
	insertar (m, 5,	"Salbutamol", 1);
	insertar (m, 2,	"Tramadol",   3);
	insertar (m, 6,	"Remdesivir", 1);
	insertar (m, 1, "Sintróm",    2); // el dato existe , no se inserta
	insertar (m, 1, "Pacetamol",  4);
	insertar (m, 7, "Sintróm",    2);
	insertar (m, 1, "Omeprazol",  2);

	cout <<"----- valor antes de comenzar a dar los turnos------"<< endl;
	mostrar(m);
	// Caso 1: dar turno a momento = 1, desayuno, veces= 1
	momento = 1;
	darTurno(m, momento);
	cout <<"----- valor de veces después de dar turno momento 1, veces = 1 ------"<< endl;
	mostrar(m);
	//  Caso 2: dar turno a momento = 1, desayuno, veces= 2
	momento = 1;
	darTurno(m, momento);
	cout <<"----- valor de veces después de dar turno momento 1, veces = 2------"<< endl;
	mostrar(m);
	// Caso 3: dar turno a momento = 2, desayuno, veces= 1
	momento = 2;
	darTurno(m, momento);
	cout <<"----- valor de veces después de dar turno momento 2, veces = 1------"<< endl;
	mostrar(m);
	cout << "FIN pruebas dar Turno"<<endl;
}

void pruebasMasVeces(){
	Medicacion m;
	string medicamento;
	int id;
	int momento;
	cout << "INICIO pruebas más veces"<<endl;
	iniciar(m);

	// insertamos el conjunto de datos con el que trabajar
	insertar (m, 1, "Sintróm",    2);
	insertar (m, 8, "Heparina ",  1);
	insertar (m, 3,	"Insulina ",  4);
	insertar (m, 5,	"Salbutamol", 1);
	insertar (m, 2,	"Tramadol",   3);
	insertar (m, 6,	"Remdesivir", 1);
	insertar (m, 1, "Sintróm",    2); // el dato existe , no se inserta
	insertar (m, 1, "Pacetamol",  4);
	insertar (m, 7, "Sintróm",    2);
	insertar (m, 1, "Omeprazol",  2);


    // Caso 1:damos turnos al momento 3
	momento = 3;
	darTurno(m, momento);
	darTurno(m, momento);
	darTurno(m, momento);
	//mostrar(m);
	cout<<endl;

	id = masVeces(m, medicamento);
	if (id != 2 || medicamento != "Tramadol"){
		cout << "Error caso 1: en la prueba de más veces"<<endl;
		cout << "El medicamento mas tomado es: "<< medicamento<<" por el paciente con id: "<< id<<endl;
	}
    // Caso 2: damos turnos al momento 4
	momento = 4;
	darTurno(m, momento);
	darTurno(m, momento);
	darTurno(m, momento);
	darTurno(m, momento);
	//mostrar(m);
	cout<<endl;
	id = masVeces(m,medicamento );
	if (id != 1 || medicamento != "Pacetamol"){
		cout << "Error caso 2: en la prueba de más veces"<<endl;
		cout << "El medicamento mas tomado es: "<< medicamento<<" por el paciente con id: "<< id<<endl;
	}
	// Caso 3:  damos turnos 5 veces al momento = 1
	momento = 1;
	darTurno(m, momento);
	darTurno(m, momento);
	darTurno(m, momento);
	darTurno(m, momento);
	darTurno(m, momento);
//	mostrar(m);
	cout<<endl;
	id = masVeces(m,medicamento );
	if (id != 5 || medicamento != "Salbutamol"){
		cout << "Error caso 3: en la prueba de más veces"<<endl;
		cout << "El medicamento mas tomado es: "<< medicamento<<" por el paciente con id: "<< id<<endl;
	}
	cout << "FIN pruebas más veces"<<endl;


}

void pruebasEliminar() {
	cout << "INICIO pruebas eliminar"<<endl;
	Medicacion m;

	iniciar(m);
	// insertamos el conjunto de datos con el que trabajar
	insertar (m, 1, "Sintróm",    2);
	insertar (m, 8, "Heparina ",  1);
	insertar (m, 3,	"Insulina ",  4);
	insertar (m, 5,	"Salbutamol", 1);
	insertar (m, 2,	"Tramadol",   3);
	insertar (m, 6,	"Remdesivir", 1);
	insertar (m, 1, "Sintróm",    2); // el dato existe , no se inserta
	insertar (m, 1, "Pacetamol",  4);
	insertar (m, 7, "Sintróm",    2);
	insertar (m, 1, "Omeprazol",  2);


	// Caso 1: Eliminar tomas paciente id = 3 (posición intermedia)
	cout << "---------datos después de eliminar id paciente = 3, ocupadas = 7"<<endl;
	eliminar(m, 3);
	if (cuantos(m) != 8)
		cout << "Error al eliminar paciente con id = 3 (posición intermedia del vector)"<<endl;

	// Caso 2: Eliminar tomas paciente id = 1 (posición inicial)
	eliminar(m, 1);
	if (cuantos(m) != 5)
		cout << "Error al eliminar paciente con id = 1 (posición inicial del vector)"<<endl;


	//Caso 3: Eliminar tomas paciente id = 8 (posición final)
	eliminar(m, 8);
	if (cuantos(m) != 4)
		cout << "Error al eliminar paciente con id = 8 (posición final del vector)"<<endl;

	cout << "FIN pruebas eliminar"<<endl;

}
void pruebasMedicacion(){
	cout << "INICIO pruebas Medicación"<<endl;
	pruebaIniciar();
	pruebasInsertar();
	pruebasDarTurno();
	pruebasMasVeces();
	pruebasEliminar();
	cout << "FIN pruebas Medicación"<<endl;
}

